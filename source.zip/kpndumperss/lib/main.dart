// KepinDumper SOURCE v4 (17 Nov 2026) — manifest fix + 5 fix Dart:
//   apk_zip 229 (nullable call), main_shell 76 (bool?), main_shell 269 (await VoidCallback),
//   float_page 49 (bool?), elf 222 (File.openSync).
// Kalau baris ini GAK ada di lib/main.dart kamu → zip lama, gak bakal lolos compile.
// Entry utama + entry overlay (flutter_overlay_window).

import 'package:flutter/material.dart';
import 'core/palette.dart';
import 'pages/auth_page.dart';
import 'overlay/overlay_app.dart';

void main() {
  runApp(const KepinDumperApp());
}

/// Entry point GUI overlay melayang (dipanggil plugin saat overlay aktif).
@pragma('vm:entry-point')
void overlayMain() {
  runApp(const OverlayApp());
}

class KepinDumperApp extends StatelessWidget {
  const KepinDumperApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'KepinDumper',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: kBgDeep,
        colorScheme: const ColorScheme.dark(
          primary: kLime,
          secondary: kMint,
          surface: kSurface,
          error: kCoral,
        ),
        fontFamily: kFontDisplay,
      ),
      home: const AuthPage(),
    );
  }
}
