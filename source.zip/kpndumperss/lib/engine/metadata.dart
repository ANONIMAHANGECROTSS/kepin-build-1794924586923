// KepinDumper engine: global-metadata.dat parser.
// Faithful port of Il2CppDumper's Metadata.cs / MetadataClass.cs with
// version gates (v24.0 - v31) and columnar storage for speed + memory.

import 'dart:typed_data';

const int metadataSanity = 0xFAB11BAF;

class MetaException implements Exception {
  final String message;
  const MetaException(this.message);
  @override
  String toString() => message;
}

class Metadata {
  final Uint8List data;
  final ByteData bd;
  final int length;

  /// 24.0, 24.1, 24.2, 24.3, 24.4, 24.5, 25, 26, 27, 28, 29, 30, 31
  double version = 0;

  // ---- header sections -------------------------------------------------------
  late int stringLiteralOffset, stringLiteralDataOffset, stringOffset;
  late int eventsOffset, propertiesOffset, methodsOffset;
  late int fieldDefaultValuesOffset, fieldAndParameterDefaultValueDataOffset;
  late int parametersOffset, fieldsOffset;
  late int genericParametersOffset, genericContainersOffset;
  late int nestedTypesOffset, interfacesOffset, vtableMethodsOffset, interfaceOffsetsOffset;
  late int typeDefinitionsOffset;
  late int imagesOffset, assembliesOffset;
  late int fieldRefsOffset, referencedAssembliesOffset;
  late int exportedTypeDefinitionsOffset;

  late int stringLiteralSize, stringLiteralDataSize, stringSize;
  late int eventsSize, propertiesSize, methodsSize;
  late int fieldDefaultValuesSize, fieldAndParameterDefaultValueDataSize;
  late int parametersSize, fieldsSize;
  late int genericParametersSize, genericContainersSize;
  late int nestedTypesSize, interfacesSize, vtableMethodsSize, interfaceOffsetsSize;
  late int typeDefinitionsSize;
  late int imagesSize, assembliesSize;

  // ---- columnar typeDefs ----------------------------------------------------
  late int typeDefCount;
  late Uint32List tdNameIdx, tdNamespaceIdx, tdFlags, tdBitfield, tdToken;
  late Int32List tdByval, tdDeclaring, tdParent, tdElement, tdGenericContainer;
  late Int32List tdFieldStart, tdMethodStart, tdEventStart, tdPropertyStart;
  late Int32List tdNestedStart, tdInterfacesStart, tdVtableStart, tdInterfaceOffsetsStart;
  late Uint16List tdMethodCount, tdPropertyCount, tdFieldCount, tdEventCount;
  late Uint16List tdNestedCount, tdVtableCount, tdInterfacesCount, tdInterfaceOffsetsCount;

  // ---- columnar methodDefs --------------------------------------------------
  late int methodDefCount;
  late Uint32List mdNameIdx, mdToken;
  late Int32List mdDeclaringType, mdReturnType, mdParameterStart, mdGenericContainer;
  late Uint16List mdFlags, mdIflags, mdSlot, mdParameterCount;

  // ---- columnar fieldDefs / params -----------------------------------------
  late int fieldDefCount, paramDefCount;
  late Uint32List fdNameIdx, fdToken;
  late Int32List fdTypeIndex;
  late Uint32List pdNameIdx, pdToken;
  late Int32List pdTypeIndex;

  // ---- images ----------------------------------------------------------------
  late int imageDefCount;
  late Uint32List imgNameIdx, imgTypeCount;
  late Int32List imgAssemblyIndex, imgTypeStart;

  // ---- misc ------------------------------------------------------------------
  late int propertyDefCount;
  late Uint32List propNameIdx, propAttrs, propToken;
  late Int32List propGet, propSet;
  late int stringLiteralCount;
  late Uint32List slLength;
  late Int32List slDataIndex;
  late int genericContainerCount;
  late Int32List gcOwner, gcTypeArgc, gcIsMethod, gcGenericParameterStart;
  late int genericParameterCount;
  late Int32List gpOwner, gpConstraintsStart, gpConstraintsCount;
  late Uint32List gpNameIdx, gpNum, gpFlags;
  late Int32List interfaceIndices;
  late int interfaceIndicesCount;
  late Int32List mdMethodIndex; // v<=24.1 (versi baru: semua 0)
  int metadataUsageListsOffset = 0, metadataUsagePairsOffset = 0;
  int metadataUsageListsSize = 0, metadataUsagePairsSize = 0;
  List<int> metadataUsageDestIndices = const [];

  final Map<int, String> _stringCache = {};

  Metadata(this.data)
      : bd = ByteData.sublistView(data),
        length = data.length;

  factory Metadata.fromFileBytes(Uint8List bytes) {
    final m = Metadata(bytes);
    m.parse();
    return m;
  }

  // ---- primitive reads ---------------------------------------------------------

  int u32(int off) => bd.getUint32(off, Endian.little);
  int u16(int off) => bd.getUint16(off, Endian.little);
  int i32(int off) => bd.getInt32(off, Endian.little);

  bool _has(double v, {double? min, double? max}) {
    if (min != null && v < min) return false;
    if (max != null && v > max) return false;
    return true;
  }

  int _sizeOfTypeDef() {
    int n = 2; // nameIdx, nsIdx
    if (_has(version, max: 24)) n += 1; // customAttributeIndex
    n += 1; // byval
    if (_has(version, max: 24.5)) n += 1; // byref
    n += 3; // declaring, parent, element
    if (_has(version, max: 24.1)) n += 2; // rgctxStart, rgctxCount
    n += 1; // genericContainer
    n += 1; // flags
    n += 8; // starts
    n += 4; // 8 x u16 counts -> 4 x u32
    n += 2; // bitfield, token
    return n * 4;
  }

  int _sizeOfMethodDef() {
    int n = 4; // name, declaring, return, paramStart
    if (_has(version, min: 31)) n += 1; // returnParameterToken
    if (_has(version, max: 24)) n += 1; // customAttributeIndex
    n += 1; // genericContainerIndex
    if (_has(version, max: 24.1)) n += 5; // methodIndex..rgctxCount
    n += 1; // token
    n += 2; // flags, iflags, slot, paramCount (4 x u16 = 2 x u32)
    return n * 4;
  }

  int _sizeOfFieldDef() {
    int n = 2; // name, typeIndex
    if (_has(version, max: 24)) n += 1; // customAttributeIndex
    n += 1; // token
    return n * 4;
  }

  int _sizeOfParamDef() {
    int n = 3; // name, token, typeIndex
    if (_has(version, max: 24)) n += 1; // customAttributeIndex
    return n * 4;
  }

  int _sizeOfImageDef() {
    int n = 4; // nameIdx, assemblyIndex, typeStart, typeCount
    if (_has(version, min: 24)) n += 2; // exportedTypeStart, exportedTypeCount
    n += 1; // entryPointIndex
    n += 1; // token
    if (_has(version, min: 24.1)) n += 2; // customAttributeStart, customAttributeCount
    return n * 4;
  }

  int _sizeOfPropertyDef() {
    int n = 4; // name, get, set, attrs
    if (_has(version, max: 24)) n += 1; // customAttributeIndex
    n += 1; // token
    return n * 4;
  }

  // ---- header ---------------------------------------------------------------

  void _readHeader() {
    // Pairs 0..19 ada di posisi tetap untuk semua versi v24+.
    stringLiteralOffset = u32(8); stringLiteralSize = i32(12);
    stringLiteralDataOffset = u32(16); stringLiteralDataSize = i32(20);
    stringOffset = u32(24); stringSize = i32(28);
    eventsOffset = u32(32); eventsSize = i32(36);
    propertiesOffset = u32(40); propertiesSize = i32(44);
    methodsOffset = u32(48); methodsSize = i32(52);
    fieldDefaultValuesOffset = u32(64); fieldDefaultValuesSize = i32(68);
    fieldAndParameterDefaultValueDataOffset = u32(72); fieldAndParameterDefaultValueDataSize = i32(76);
    parametersOffset = u32(88); parametersSize = i32(92);
    fieldsOffset = u32(96); fieldsSize = i32(100);
    genericParametersOffset = u32(104); genericParametersSize = i32(108);
    genericContainersOffset = u32(120); genericContainersSize = i32(124);
    nestedTypesOffset = u32(128); nestedTypesSize = i32(132);
    interfacesOffset = u32(136); interfacesSize = i32(140);
    vtableMethodsOffset = u32(144); vtableMethodsSize = i32(148);
    interfaceOffsetsOffset = u32(152); interfaceOffsetsSize = i32(156);
    typeDefinitionsOffset = u32(160); typeDefinitionsSize = i32(164);

    // Pairs 20+ bergantung versi (persis gate Il2CppGlobalMetadataHeader).
    int pos = 168;
    if (version <= 24.1) pos += 8; // rgctxEntriesOffset/Count
    imagesOffset = u32(pos); imagesSize = i32(pos + 4); pos += 8;
    assembliesOffset = u32(pos); assembliesSize = i32(pos + 4); pos += 8;
    if (version <= 24.5) {
      metadataUsageListsOffset = u32(pos);
      metadataUsageListsSize = i32(pos + 4);
      metadataUsagePairsOffset = u32(pos + 8);
      metadataUsagePairsSize = i32(pos + 12);
      pos += 16; // metadataUsageLists + metadataUsagePairs
    }
    fieldRefsOffset = u32(pos); pos += 8;
    referencedAssembliesOffset = u32(pos); pos += 8;
    if (version >= 21 && version <= 27.2) pos += 16; // attributesInfo + attributeTypes
    if (version >= 29) pos += 16; // attributeData + attributeDataRange
    if (version >= 22) pos += 16; // unresolvedVirtualCallParameterTypes + Ranges
    if (version >= 23) pos += 8; // windowsRuntimeTypeNames
    if (version >= 27) pos += 8; // windowsRuntimeStrings
    exportedTypeDefinitionsOffset = u32(pos);
  }

  // ---- main parse -----------------------------------------------------------

  void parse() {
    if (length < 64) {
      throw const MetaException('File global-metadata.dat kekecilan / rusak.');
    }
    final sanity = u32(0);
    if (sanity != metadataSanity) {
      throw const MetaException('Magic file salah (0xFAB11BAF gak ketemu) — ini bukan global-metadata.dat.');
    }
    final v = i32(4);
    if (v < 0 || v > 1000) {
      throw const MetaException('Versi metadata gak valid.');
    }
    if (v < 24 || v > 31) {
      throw MetaException('Versi metadata v$v di luar jangkauan engine (support v24 - v31). Game terlalu lama / terlalu baru.');
    }
    version = v.toDouble();

    if (v == 24) {
      // Baca tentatif dengan layout v24.0 (rgctx masuk).
      _readHeader();
      if (stringLiteralOffset == 264) {
        version = 24.2;
        _readHeader();
      } else {
        _readImages();
        bool anyTokenNot1 = false;
        for (int i = 0; i < imageDefCount; i++) {
          if (imgTokenAt(i) != 1) {
            anyTokenNot1 = true;
            break;
          }
        }
        if (anyTokenNot1) version = 24.1;
      }
    } else {
      _readHeader();
    }

    if (version == 24.2 || version == 24.1) {
      _readImages();
      if (version == 24.2 && assembliesSize ~/ 68 < imageDefCount) {
        version = 24.4;
      }
      if (version == 24.1 && assembliesSize ~/ 64 == imageDefCount) {
        version = 24.4;
      }
    }

    _readImages();
    _readTypeDefs();
    _readMethodDefs();
    _readParamDefs();
    _readFieldDefs();
    _readProperties();
    _readStringLiterals();
    _readGenericContainers();
    _readGenericParameters();
    _readInterfaceIndices();
    _readMetadataUsages();

    // sanity: jumlah method/field dari typeDef harus cocok dengan section size
    int sumMethods = 0;
    int sumFields = 0;
    for (int i = 0; i < typeDefCount; i++) {
      sumMethods += tdMethodCount[i];
      sumFields += tdFieldCount[i];
    }
    final expectedMethods = methodsSize ~/ _sizeOfMethodDef();
    final expectedFields = fieldsSize ~/ _sizeOfFieldDef();
    if (expectedMethods > 0 && sumMethods != expectedMethods) {
      throw const MetaException('Layout methodDef gak cocok (jumlah method gak nyambung). Metadata mungkin di-obfuscate.');
    }
    if (expectedFields > 0 && sumFields != expectedFields) {
      throw const MetaException('Layout fieldDef gak cocok (jumlah field gak nyambung). Metadata mungkin di-obfuscate.');
    }
    methodDefCount = expectedMethods;
    fieldDefCount = expectedFields;
  }

  // ---- readers -----------------------------------------------------------------

  void _readImages() {
    final size = _sizeOfImageDef();
    imageDefCount = imagesSize ~/ size;
    if (imageDefCount <= 0 || imageDefCount > 20000) {
      throw const MetaException('Jumlah image (assembly) absurd — file corrupt / di-obfuscate.');
    }
    imgNameIdx = Uint32List(imageDefCount);
    imgTypeCount = Uint32List(imageDefCount);
    imgAssemblyIndex = Int32List(imageDefCount);
    imgTypeStart = Int32List(imageDefCount);
    final stride = size;
    for (int i = 0; i < imageDefCount; i++) {
      final b = imagesOffset + i * stride;
      imgNameIdx[i] = u32(b);
      imgAssemblyIndex[i] = i32(b + 4);
      imgTypeStart[i] = i32(b + 8);
      imgTypeCount[i] = u32(b + 12);
    }
  }

  int imgTokenAt(int i) => u32(imagesOffset + i * _sizeOfImageDef() + 28);

  void _readTypeDefs() {
    final size = _sizeOfTypeDef();
    typeDefCount = typeDefinitionsSize ~/ size;
    if (typeDefCount <= 0 || typeDefCount > 400000) {
      throw const MetaException('Jumlah typeDef absurd — file corrupt / di-obfuscate.');
    }
    // precompute field offsets once
    final v = version;
    final hasCustomAttr = v <= 24;
    final hasByref = v <= 24.5;
    final hasRgctx = v <= 24.1;
    int o = 0;
    final offName = o; o += 4;
    final offNs = o; o += 4;
    if (hasCustomAttr) o += 4;
    final offByval = o; o += 4;
    if (hasByref) o += 4;
    final offDeclaring = o; o += 4;
    final offParent = o; o += 4;
    final offElement = o; o += 4;
    if (hasRgctx) o += 8;
    final offGenericContainer = o; o += 4;
    final offFlags = o; o += 4;
    final offFieldStart = o; o += 4;
    final offMethodStart = o; o += 4;
    final offEventStart = o; o += 4;
    final offPropertyStart = o; o += 4;
    final offNestedStart = o; o += 4;
    final offInterfacesStart = o; o += 4;
    final offVtableStart = o; o += 4;
    final offIfaceOffsetsStart = o; o += 4;
    final offCounts = o; // 8 x u16

    tdNameIdx = Uint32List(typeDefCount);
    tdNamespaceIdx = Uint32List(typeDefCount);
    tdFlags = Uint32List(typeDefCount);
    tdBitfield = Uint32List(typeDefCount);
    tdToken = Uint32List(typeDefCount);
    tdByval = Int32List(typeDefCount);
    tdDeclaring = Int32List(typeDefCount);
    tdParent = Int32List(typeDefCount);
    tdElement = Int32List(typeDefCount);
    tdGenericContainer = Int32List(typeDefCount);
    tdFieldStart = Int32List(typeDefCount);
    tdMethodStart = Int32List(typeDefCount);
    tdEventStart = Int32List(typeDefCount);
    tdPropertyStart = Int32List(typeDefCount);
    tdNestedStart = Int32List(typeDefCount);
    tdInterfacesStart = Int32List(typeDefCount);
    tdVtableStart = Int32List(typeDefCount);
    tdInterfaceOffsetsStart = Int32List(typeDefCount);
    tdMethodCount = Uint16List(typeDefCount);
    tdPropertyCount = Uint16List(typeDefCount);
    tdFieldCount = Uint16List(typeDefCount);
    tdEventCount = Uint16List(typeDefCount);
    tdNestedCount = Uint16List(typeDefCount);
    tdVtableCount = Uint16List(typeDefCount);
    tdInterfacesCount = Uint16List(typeDefCount);
    tdInterfaceOffsetsCount = Uint16List(typeDefCount);

    for (int i = 0; i < typeDefCount; i++) {
      final b = typeDefinitionsOffset + i * size;
      tdNameIdx[i] = u32(b + offName);
      tdNamespaceIdx[i] = u32(b + offNs);
      tdByval[i] = i32(b + offByval);
      tdDeclaring[i] = i32(b + offDeclaring);
      tdParent[i] = i32(b + offParent);
      tdElement[i] = i32(b + offElement);
      tdGenericContainer[i] = i32(b + offGenericContainer);
      tdFlags[i] = u32(b + offFlags);
      tdFieldStart[i] = i32(b + offFieldStart);
      tdMethodStart[i] = i32(b + offMethodStart);
      tdEventStart[i] = i32(b + offEventStart);
      tdPropertyStart[i] = i32(b + offPropertyStart);
      tdNestedStart[i] = i32(b + offNestedStart);
      tdInterfacesStart[i] = i32(b + offInterfacesStart);
      tdVtableStart[i] = i32(b + offVtableStart);
      tdInterfaceOffsetsStart[i] = i32(b + offIfaceOffsetsStart);
      final c = b + offCounts;
      tdMethodCount[i] = u16(c);
      tdPropertyCount[i] = u16(c + 2);
      tdFieldCount[i] = u16(c + 4);
      tdEventCount[i] = u16(c + 6);
      tdNestedCount[i] = u16(c + 8);
      tdVtableCount[i] = u16(c + 10);
      tdInterfacesCount[i] = u16(c + 12);
      tdInterfaceOffsetsCount[i] = u16(c + 14);
      tdBitfield[i] = u32(b + offCounts + 16);
      tdToken[i] = u32(b + offCounts + 20);
    }
  }

  void _readMethodDefs() {
    final size = _sizeOfMethodDef();
    final n = methodsSize ~/ size;
    final v = version;
    final hasCustomAttr = v <= 24;
    final hasOldIndices = v <= 24.1;
    final hasReturnParamToken = v >= 31;
    int o = 0;
    final offName = o; o += 4;
    final offDeclaring = o; o += 4;
    final offReturnType = o; o += 4;
    if (hasReturnParamToken) o += 4;
    final offParamStart = o; o += 4;
    if (hasCustomAttr) o += 4;
    final offGenericContainer = o; o += 4;
    if (hasOldIndices) o += 20;
    final offToken = o; o += 4;
    final offFlags = o;

    mdNameIdx = Uint32List(n);
    mdToken = Uint32List(n);
    mdDeclaringType = Int32List(n);
    mdReturnType = Int32List(n);
    mdParameterStart = Int32List(n);
    mdGenericContainer = Int32List(n);
    mdFlags = Uint16List(n);
    mdIflags = Uint16List(n);
    mdSlot = Uint16List(n);
    mdParameterCount = Uint16List(n);
    mdMethodIndex = Int32List(n);

    for (int i = 0; i < n; i++) {
      final b = methodsOffset + i * size;
      mdNameIdx[i] = u32(b + offName);
      mdDeclaringType[i] = i32(b + offDeclaring);
      mdReturnType[i] = i32(b + offReturnType);
      mdParameterStart[i] = i32(b + offParamStart);
      mdGenericContainer[i] = i32(b + offGenericContainer);
      if (hasOldIndices) {
        mdMethodIndex[i] = i32(b + offGenericContainer + 4);
      }
      mdToken[i] = u32(b + offToken);
      mdFlags[i] = u16(b + offFlags);
      mdIflags[i] = u16(b + offFlags + 2);
      mdSlot[i] = u16(b + offFlags + 4);
      mdParameterCount[i] = u16(b + offFlags + 6);
    }
  }

  void _readParamDefs() {
    final size = _sizeOfParamDef();
    final v = version;
    final hasCustomAttr = v <= 24;
    final n = parametersSize ~/ size;
    pdNameIdx = Uint32List(n);
    pdToken = Uint32List(n);
    pdTypeIndex = Int32List(n);
    for (int i = 0; i < n; i++) {
      final b = parametersOffset + i * size;
      pdNameIdx[i] = u32(b);
      pdToken[i] = u32(b + 4);
      pdTypeIndex[i] = i32(b + (hasCustomAttr ? 12 : 8));
    }
    paramDefCount = n;
  }

  void _readFieldDefs() {
    final size = _sizeOfFieldDef();
    final v = version;
    final hasCustomAttr = v <= 24;
    final n = fieldsSize ~/ size;
    fdNameIdx = Uint32List(n);
    fdToken = Uint32List(n);
    fdTypeIndex = Int32List(n);
    for (int i = 0; i < n; i++) {
      final b = fieldsOffset + i * size;
      fdNameIdx[i] = u32(b);
      fdTypeIndex[i] = i32(b + 4);
      fdToken[i] = u32(b + (hasCustomAttr ? 12 : 8));
    }
  }

  void _readProperties() {
    final size = _sizeOfPropertyDef();
    final v = version;
    final hasCustomAttr = v <= 24;
    final n = propertiesSize ~/ size;
    propNameIdx = Uint32List(n);
    propGet = Int32List(n);
    propSet = Int32List(n);
    propAttrs = Uint32List(n);
    propToken = Uint32List(n);
    for (int i = 0; i < n; i++) {
      final b = propertiesOffset + i * size;
      propNameIdx[i] = u32(b);
      propGet[i] = i32(b + 4);
      propSet[i] = i32(b + 8);
      propAttrs[i] = u32(b + 12);
      propToken[i] = u32(b + (hasCustomAttr ? 20 : 16));
    }
    propertyDefCount = n;
  }

  void _readStringLiterals() {
    final n = stringLiteralSize ~/ 8;
    slLength = Uint32List(n);
    slDataIndex = Int32List(n);
    for (int i = 0; i < n; i++) {
      final b = stringLiteralOffset + i * 8;
      slLength[i] = u32(b);
      slDataIndex[i] = i32(b + 4);
    }
    stringLiteralCount = n;
  }

  void _readGenericContainers() {
    final n = genericContainersSize ~/ 16;
    gcOwner = Int32List(n);
    gcTypeArgc = Int32List(n);
    gcIsMethod = Int32List(n);
    gcGenericParameterStart = Int32List(n);
    for (int i = 0; i < n; i++) {
      final b = genericContainersOffset + i * 16;
      gcOwner[i] = i32(b);
      gcTypeArgc[i] = i32(b + 4);
      gcIsMethod[i] = i32(b + 8);
      gcGenericParameterStart[i] = i32(b + 12);
    }
    genericContainerCount = n;
  }

  void _readGenericParameters() {
    final n = genericParametersSize ~/ 16;
    gpOwner = Int32List(n);
    gpNameIdx = Uint32List(n);
    gpConstraintsStart = Int32List(n);
    gpConstraintsCount = Int32List(n);
    gpNum = Uint32List(n);
    gpFlags = Uint32List(n);
    for (int i = 0; i < n; i++) {
      final b = genericParametersOffset + i * 16;
      gpOwner[i] = i32(b);
      gpNameIdx[i] = u32(b + 4);
      gpConstraintsStart[i] = i32(b + 8); // i16 pair packed
      gpConstraintsCount[i] = i32(b + 10);
      gpNum[i] = u32(b + 12);
      gpFlags[i] = u32(b + 14);
    }
    genericParameterCount = n;
  }

  void _readInterfaceIndices() {
    final n = interfacesSize ~/ 4;
    interfaceIndices = Int32List(n);
    for (int i = 0; i < n; i++) {
      interfaceIndices[i] = i32(interfacesOffset + i * 4);
    }
    interfaceIndicesCount = n;
  }

  void _readMetadataUsages() {
    if (version > 24.5) return;
    if (metadataUsageListsSize <= 0 || metadataUsagePairsSize <= 0) return;
    final listCount = metadataUsageListsSize ~/ 8;
    final pairCount = metadataUsagePairsSize ~/ 8;
    if (listCount <= 0 || pairCount <= 0 || listCount > 4000000 || pairCount > 4000000) return;
    final dest = <int>[];
    for (int i = 0; i < listCount; i++) {
      final b = metadataUsageListsOffset + i * 8;
      final start = u32(b);
      final count = u32(b + 4);
      if (count > 4000000) continue;
      for (int j = 0; j < count; j++) {
        final off = start + j;
        if (off < 0 || off >= pairCount) continue;
        dest.add(u32(metadataUsagePairsOffset + off * 8));
      }
    }
    metadataUsageDestIndices = dest;
  }

  // ---- string access -----------------------------------------------------------

  String getStringFromIndex(int index) {
    if (index < 0) return '';
    final cached = _stringCache[index];
    if (cached != null) return cached;
    if (index >= stringSize) return '';
    final off = stringOffset + index;
    final sb = StringBuffer();
    for (int i = off; i < length; i++) {
      final b = data[i];
      if (b == 0) break;
      sb.writeCharCode(b);
    }
    final s = sb.toString();
    _stringCache[index] = s;
    return s;
  }

  /// String literal (managed code strings) by literal index.
  String getStringLiteral(int index) {
    if (index < 0 || index >= stringLiteralCount) return '';
    final len = slLength[index];
    final start = stringLiteralDataOffset + slDataIndex[index];
    if (start < 0 || start + len > length) return '';
    // UTF-8 decode
    return utf8Decode(data, start, len);
  }

  static String utf8Decode(Uint8List bytes, int start, int len) {
    // Simple UTF-8 decoder (avoids dart:convert dependency issues in isolates).
    final sb = StringBuffer();
    int i = start;
    final end = start + len;
    while (i < end) {
      final b = bytes[i];
      if (b < 0x80) {
        sb.writeCharCode(b);
        i += 1;
      } else if ((b & 0xE0) == 0xC0 && i + 1 < end) {
        sb.writeCharCode(((b & 0x1F) << 6) | (bytes[i + 1] & 0x3F));
        i += 2;
      } else if ((b & 0xF0) == 0xE0 && i + 2 < end) {
        sb.writeCharCode(((b & 0x0F) << 12) | ((bytes[i + 1] & 0x3F) << 6) | (bytes[i + 2] & 0x3F));
        i += 3;
      } else if ((b & 0xF8) == 0xF0 && i + 3 < end) {
        final cp = ((b & 0x07) << 18) | ((bytes[i + 1] & 0x3F) << 12) | ((bytes[i + 2] & 0x3F) << 6) | (bytes[i + 3] & 0x3F);
        sb.writeCharCode(0x10000 + (cp - 0x10000));
        i += 4;
      } else {
        sb.writeCharCode(0xFFFD);
        i += 1;
      }
    }
    return sb.toString();
  }

  bool typeIsValueType(int i) => (tdBitfield[i] & 0x1) == 1;
  bool typeIsEnum(int i) => ((tdBitfield[i] >> 1) & 0x1) == 1;
}
