// KepinDumper engine: ELF (libil2cpp.so) reader.
// Port of Il2CppDumper's Elf/Elf64 parsing with a paged, memory-bounded
// file accessor so huge game binaries (100-300MB) never get fully loaded.

import 'dart:io';
import 'dart:typed_data';

// ---- ELF constants -------------------------------------------------------

const int PT_LOAD = 1;
const int PT_DYNAMIC = 2;

const int DT_PLTGOT = 3;
const int DT_HASH = 4;
const int DT_STRTAB = 5;
const int DT_SYMTAB = 6;
const int DT_RELA = 7;
const int DT_RELASZ = 8;
const int DT_INIT = 12;
const int DT_REL = 17;
const int DT_RELSZ = 18;
const int DT_JMPREL = 23;
const int DT_GNU_HASH = 0x6ffffef5;

const int EM_386 = 3;
const int EM_ARM = 40;
const int EM_X86_64 = 62;
const int EM_AARCH64 = 183;

const int R_386_32 = 1;
const int R_ARM_ABS32 = 3;
const int R_X86_64_64 = 1;
const int R_X86_64_RELATIVE = 8;
const int R_AARCH64_ABS64 = 257;
const int R_AARCH64_RELATIVE = 1023;

// ---- Paged file accessor --------------------------------------------------

class SoFile {
  final RandomAccessFile _raf;
  final int length;
  final int pointerSize;
  final int _pageSize = 1 << 20;
  final Map<int, Uint8List> _pages = {};
  final Map<int, ByteData> _views = {};
  final Set<int> _dirty = {};
  final List<int> _lru = [];

  static const int _maxPages = 80;

  SoFile(this._raf, this.length, this.pointerSize);

  void close() {
    try {
      _raf.close();
    } catch (_) {}
  }

  Uint8List _pageAt(int idx) {
    final p = _pages[idx];
    if (p != null) {
      final li = _lru.indexOf(idx);
      if (li >= 0) _lru.removeAt(li);
      _lru.add(idx);
      return p;
    }
    while (_pages.length >= _maxPages && _lru.isNotEmpty) {
      final evict = _lru.removeAt(0);
      if (!_dirty.contains(evict)) {
        _pages.remove(evict);
        _views.remove(evict);
      }
    }
    final start = idx * _pageSize;
    int n = _pageSize;
    if (start >= length) n = 0;
    if (start + n > length) n = length - start;
    final data = Uint8List(_pageSize);
    if (n > 0) {
      _raf.setPositionSync(start);
      final got = _raf.readSync(n);
      data.setRange(0, n, got);
    }
    _pages[idx] = data;
    _views[idx] = ByteData.sublistView(data);
    _lru.add(idx);
    return data;
  }

  ByteData _viewAt(int idx) {
    _pageAt(idx);
    return _views[idx] as ByteData;
  }

  int u16At(int off) {
    final v = _viewAt(off ~/ _pageSize);
    return v.getUint16(off % _pageSize, Endian.little);
  }

  int u32At(int off) {
    final v = _viewAt(off ~/ _pageSize);
    return v.getUint32(off % _pageSize, Endian.little);
  }

  int u64At(int off) {
    final o = off % _pageSize;
    if (o + 8 <= _pageSize) {
      final v = _viewAt(off ~/ _pageSize);
      return v.getUint64(o, Endian.little);
    }
    return u32At(off) | (u32At(off + 4) << 32);
  }

  /// Pointer-sized integer read (4 or 8 bytes).
  int ptrAt(int off) => pointerSize == 8 ? u64At(off) : u32At(off);

  void writeU32(int off, int value) {
    final idx = off ~/ _pageSize;
    final v = _viewAt(idx);
    v.setUint32(off % _pageSize, value & 0xFFFFFFFF, Endian.little);
    _dirty.add(idx);
  }

  void writeU64(int off, int value) {
    final idx = off ~/ _pageSize;
    final o = off % _pageSize;
    if (o + 8 <= _pageSize) {
      final v = _viewAt(idx);
      v.setUint64(o, value & 0xFFFFFFFFFFFFFFFF, Endian.little);
      _dirty.add(idx);
    } else {
      writeU32(off, value & 0xFFFFFFFF);
      writeU32(off + 4, (value >> 32) & 0xFFFFFFFF);
    }
  }

  void writePtr(int off, int value) {
    if (pointerSize == 8) {
      writeU64(off, value);
    } else {
      writeU32(off, value);
    }
  }

  Uint8List readBytes(int off, int len) {
    if (len <= 0) return Uint8List(0);
    final out = Uint8List(len);
    int done = 0;
    while (done < len) {
      final idx = (off + done) ~/ _pageSize;
      final o = (off + done) % _pageSize;
      final take = (len - done < _pageSize - o) ? len - done : _pageSize - o;
      final page = _pageAt(idx);
      out.setRange(done, done + take, page, o);
      done += take;
    }
    return out;
  }

  /// NUL terminated string at file offset.
  String readCString(int off, [int maxLen = 4096]) {
    final sb = StringBuffer();
    for (int i = 0; i < maxLen; i++) {
      final b = u32At(off + i) & 0xFF;
      if (b == 0) break;
      sb.writeCharCode(b);
    }
    return sb.toString();
  }
}

// ---- Program headers --------------------------------------------------------

class ElfPhdr {
  final int type;
  final int flags;
  final int offset;
  final int vaddr;
  final int filesz;
  final int memsz;
  const ElfPhdr(this.type, this.flags, this.offset, this.vaddr, this.filesz, this.memsz);
  bool get writable => (flags & 2) != 0;
  bool get executable => (flags & 1) != 0;
}

class SearchSection {
  final int offset; // file offset
  final int offsetEnd;
  final int address; // vaddr
  final int addressEnd;
  const SearchSection(this.offset, this.offsetEnd, this.address, this.addressEnd);
}

class ElfSymbol {
  final String name;
  final int value;
  const ElfSymbol(this.name, this.value);
}

// ---- ELF image --------------------------------------------------------------

class ElfImage {
  final SoFile file;
  final bool is32;
  final int machine;
  final List<ElfPhdr> phdrs = [];
  final List<ElfPhdr> execPhdrs = [];
  final List<ElfPhdr> dataPhdrs = [];
  final List<SearchSection> execSections = [];
  final List<SearchSection> dataSections = [];
  final List<ElfSymbol> dynamicSymbols = [];
  final Map<String, int> _dynmap = {};
  final Map<int, int> _dynamicEntries = {};
  bool relocationsApplied = false;
  String? protectionWarning;

  int get pointerSize => file.pointerSize;

  ElfImage(this.file, this.is32, this.machine);

  factory ElfImage.open(String path) {
    final raf = File(path).openSync(mode: FileMode.read);
    final len = raf.lengthSync();
    raf.setPositionSync(0);
    final head = raf.readSync(64);
    if (head.length < 20 || head[0] != 0x7F || head[1] != 0x45 || head[2] != 0x4C || head[3] != 0x46) {
      raf.closeSync();
      throw const FormatException('Bukan file ELF (magic 0x7F ELF tidak ketemu).');
    }
    final is32 = head[4] == 1;
    final machine = head[18] | (head[19] << 8);
    final sf = SoFile(raf, len, is32 ? 4 : 8);
    final img = ElfImage(sf, is32, machine);
    img._load();
    return img;
  }

  void _load() {
    int phoff, phentsize, phnum;
    if (is32) {
      phoff = file.u32At(28);
      phentsize = file.u16At(42);
      phnum = file.u16At(44);
    } else {
      phoff = file.u64At(32);
      phentsize = file.u16At(54);
      phnum = file.u16At(56);
    }
    if (phnum <= 0 || phnum > 200) {
      throw const FormatException('Header ELF rusak (phnum aneh).');
    }
    for (int i = 0; i < phnum; i++) {
      final base = phoff + i * phentsize;
      int type, flags, offset, vaddr, filesz, memsz;
      if (is32) {
        type = file.u32At(base);
        flags = file.u32At(base + 24);
        offset = file.u32At(base + 4);
        vaddr = file.u32At(base + 8);
        filesz = file.u32At(base + 16);
        memsz = file.u32At(base + 20);
      } else {
        type = file.u32At(base);
        flags = file.u32At(base + 4);
        offset = file.u64At(base + 8);
        vaddr = file.u64At(base + 16);
        filesz = file.u64At(base + 32);
        memsz = file.u64At(base + 40);
      }
      final ph = ElfPhdr(type, flags, offset, vaddr, filesz, memsz);
      phdrs.add(ph);
      if (type == PT_LOAD && memsz != 0) {
        if (flags == 1 || flags == 3 || flags == 5 || flags == 7) {
          execPhdrs.add(ph);
          execSections.add(SearchSection(offset, offset + filesz, vaddr, vaddr + memsz));
        } else if (flags == 2 || flags == 4 || flags == 6) {
          dataPhdrs.add(ph);
          dataSections.add(SearchSection(offset, offset + filesz, vaddr, vaddr + memsz));
        }
      }
    }
    if (execSections.isEmpty) {
      throw const FormatException('Segment exec (.text) gak ada di ELF ini.');
    }
    if (dataSections.isEmpty) {
      throw const FormatException('Segment data gak ada di ELF ini.');
    }
    _readDynamic();
    _readSymbols();
    _applyRelocations();
    _checkProtection();
  }

  void _readDynamic() {
    ElfPhdr? dyn;
    for (final p in phdrs) {
      if (p.type == PT_DYNAMIC) {
        dyn = p;
        break;
      }
    }
    if (dyn == null) return;
    final entrySize = is32 ? 8 : 16;
    final count = dyn.filesz ~/ entrySize;
    for (int i = 0; i < count; i++) {
      final base = dyn.offset + i * entrySize;
      final tag = is32 ? file.u32At(base) : file.u64At(base);
      final un = is32 ? file.u32At(base + 4) : file.u64At(base + 8);
      if (tag == 0) break;
      _dynamicEntries[tag] = un;
    }
  }

  /// virtual address -> file offset
  int mapVATR(int addr) {
    for (final p in phdrs) {
      if (addr >= p.vaddr && addr <= p.vaddr + p.memsz) {
        return addr - p.vaddr + p.offset;
      }
    }
    return 0;
  }

  /// file offset -> virtual address
  int mapRTVA(int off) {
    for (final p in phdrs) {
      if (off >= p.offset && off <= p.offset + p.filesz) {
        return off - p.offset + p.vaddr;
      }
    }
    return 0;
  }

  void _readSymbols() {
    try {
      final strtabVa = _dynamicEntries[DT_STRTAB];
      final symtabVa = _dynamicEntries[DT_SYMTAB];
      if (strtabVa == null || symtabVa == null) return;
      final strtabOff = mapVATR(strtabVa);
      int symbolCount = 0;
      final hashVa = _dynamicEntries[DT_HASH];
      if (hashVa != null) {
        final hOff = mapVATR(hashVa);
        final nchain = file.u32At(hOff + 4);
        symbolCount = nchain;
      } else {
        final gnuVa = _dynamicEntries[DT_GNU_HASH];
        if (gnuVa == null) return;
        final hOff = mapVATR(gnuVa);
        final nbuckets = file.u32At(hOff);
        final symoffset = file.u32At(hOff + 4);
        final bloomSize = file.u32At(hOff + 8);
        final bucketsAddress = hOff + 16 + (is32 ? 4 : 8) * bloomSize;
        int lastSymbol = 0;
        for (int i = 0; i < nbuckets; i++) {
          final b = file.u32At(bucketsAddress + 4 * i);
          if (b > lastSymbol) lastSymbol = b;
        }
        if (lastSymbol < symoffset) {
          symbolCount = symoffset;
        } else {
          final chainsBase = bucketsAddress + 4 * nbuckets;
          int pos = chainsBase + (lastSymbol - symoffset) * 4;
          while (true) {
            final chain = file.u32At(pos);
            lastSymbol++;
            if ((chain & 1) != 0) break;
            pos += 4;
            if (pos > file.length) break;
          }
          symbolCount = lastSymbol;
        }
      }
      if (symbolCount <= 0 || symbolCount > 4000000) return;
      final symSize = is32 ? 16 : 24;
      final symOff = mapVATR(symtabVa);
      for (int i = 0; i < symbolCount; i++) {
        final base = symOff + i * symSize;
        if (base + symSize > file.length) break;
        final stName = file.u32At(base);
        int stValue;
        if (is32) {
          stValue = file.u32At(base + 4);
        } else {
          stValue = file.u64At(base + 8);
        }
        if (stName == 0) continue;
        final name = file.readCString(strtabOff + stName, 256);
        if (name.isEmpty) continue;
        dynamicSymbols.add(ElfSymbol(name, stValue));
        _dynmap[name] = stValue;
      }
    } catch (_) {
      // ignored, sama seperti referensi
    }
  }

  int symbolValue(String name) => _dynmap[name] ?? 0;

  void _applyRelocations() {
    if (relocationsApplied) return;
    relocationsApplied = true;
    try {
      if (!is32) {
        final relaVa = _dynamicEntries[DT_RELA];
        final relaSz = _dynamicEntries[DT_RELASZ];
        if (relaVa == null || relaSz == null || relaSz <= 0) return;
        final relaOff = mapVATR(relaVa);
        final count = relaSz ~/ 24;
        for (int i = 0; i < count; i++) {
          final base = relaOff + i * 24;
          if (base + 24 > file.length) break;
          final rOffset = file.u64At(base);
          final rInfo = file.u64At(base + 8);
          final rAddend = file.u64At(base + 16);
          final type = rInfo & 0xFFFFFFFF;
          final sym = rInfo >> 32;
          int value = 0;
          bool recognized = false;
          if (machine == EM_AARCH64) {
            if (type == R_AARCH64_ABS64) {
              value = symbolValueAt(sym) + rAddend;
              recognized = true;
            } else if (type == R_AARCH64_RELATIVE) {
              value = rAddend;
              recognized = true;
            }
          } else if (machine == EM_X86_64) {
            if (type == R_X86_64_64) {
              value = symbolValueAt(sym) + rAddend;
              recognized = true;
            } else if (type == R_X86_64_RELATIVE) {
              value = rAddend;
              recognized = true;
            }
          }
          if (recognized) {
            final target = mapVATR(rOffset);
            if (target != 0 && target + 8 <= file.length) {
              file.writeU64(target, value);
            }
          }
        }
      } else {
        final relVa = _dynamicEntries[DT_REL];
        final relSz = _dynamicEntries[DT_RELSZ];
        if (relVa == null || relSz == null || relSz <= 0) return;
        final relOff = mapVATR(relVa);
        final count = relSz ~/ 8;
        final isx86 = machine == EM_386;
        for (int i = 0; i < count; i++) {
          final base = relOff + i * 8;
          if (base + 8 > file.length) break;
          final rOffset = file.u32At(base);
          final rInfo = file.u32At(base + 4);
          final type = rInfo & 0xFF;
          final sym = rInfo >> 8;
          if ((type == R_386_32 && isx86) || (type == R_ARM_ABS32 && !isx86)) {
            final target = mapVATR(rOffset);
            if (target != 0 && target + 4 <= file.length) {
              file.writeU32(target, symbolValueAt(sym));
            }
          }
        }
      }
    } catch (_) {
      // ignored
    }
  }

  int symbolValueAt(int symIndex) {
    if (symIndex <= 0 || symIndex > dynamicSymbols.length) return 0;
    return dynamicSymbols[symIndex - 1].value;
  }

  void _checkProtection() {
    try {
      if (_dynamicEntries.containsKey(DT_INIT)) {
        protectionWarning = 'File ini punya .init_proc (mungkin diproteksi).';
      }
    } catch (_) {}
  }

  // ---- scanning helpers -----------------------------------------------------

  /// Find all ADDRESSES (VA) of slots in data sections whose pointer == addr.
  Iterable<int> findReferences(int addr) sync* {
    final ps = file.pointerSize;
    for (final sec in dataSections) {
      final end = sec.offsetEnd - ps;
      int pos = sec.offset;
      while (pos <= end) {
        if (pos + ps > file.length) break;
        if (file.ptrAt(pos) == addr) {
          yield pos - sec.offset + sec.address;
        }
        pos += ps;
      }
    }
  }

  /// Find first occurrence of [pattern] in the given file range, streaming.
  int searchBytes(List<int> pattern, int startOff, int endOff) {
    if (pattern.isEmpty || endOff <= startOff) return -1;
    final chunkSize = 1 << 22; // 4MB
    final overlap = pattern.length - 1;
    int pos = startOff;
    while (pos < endOff) {
      int len = chunkSize;
      if (pos + len > endOff) len = endOff - pos;
      final buff = file.readBytes(pos, len);
      for (int i = 0; i <= buff.length - pattern.length; i++) {
        bool hit = true;
        for (int j = 0; j < pattern.length; j++) {
          if (buff[i + j] != pattern[j]) {
            hit = false;
            break;
          }
        }
        if (hit) return pos + i;
      }
      pos += len - overlap;
      if (pos < startOff) pos = startOff;
    }
    return -1;
  }
}
