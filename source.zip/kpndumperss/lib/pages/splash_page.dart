// KepinDumper: splash — video welcome (muted), auto lanjut ke main page.

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import '../core/palette.dart';
import 'main_shell.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});
  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  VideoPlayerController? _controller;
  bool _went = false;
  Timer? _fallbackTimer;

  @override
  void initState() {
    super.initState();
    // fallback kalau video gagal/lemot: 9 detik langsung masuk
    _fallbackTimer = Timer(const Duration(seconds: 9), _go);
    _init();
  }

  Future<void> _init() async {
    final c = VideoPlayerController.networkUrl(
      Uri.parse('https://files.catbox.moe/h9zmv2.mp4'),
    );
    try {
      await c.initialize();
      await c.setVolume(0); // muted
      if (_went) {
        c.dispose();
        return;
      }
      setState(() => _controller = c);
      await c.play();
      c.addListener(_onTick);
    } catch (_) {
      try {
        c.dispose();
      } catch (_) {}
      // gagal load: tunggu 1.2s lalu masuk
      Timer(const Duration(milliseconds: 1200), _go);
    }
  }

  void _onTick() {
    final c = _controller;
    if (c == null) return;
    final v = c.value;
    if (v.position >= v.duration ||
        (v.position.inMilliseconds + 350 >= v.duration.inMilliseconds && v.isInitialized)) {
      _go();
    }
  }

  void _go() {
    if (_went || !mounted) return;
    _went = true;
    _fallbackTimer?.cancel();
    Navigator.of(context).pushReplacement(kFadeRoute(const MainShell(), begin: const Offset(0, 0.02)));
  }

  @override
  void dispose() {
    _fallbackTimer?.cancel();
    _controller?.removeListener(_onTick);
    try {
      _controller?.dispose();
    } catch (_) {}
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    final c = _controller;
    return Scaffold(
      backgroundColor: kBgDeep,
      body: Stack(
        children: [
          if (c != null && c.value.isInitialized)
            Positioned.fill(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: c.value.size.width,
                  height: c.value.size.height,
                  child: VideoPlayer(c),
                ),
              ),
            )
          else
            Positioned.fill(
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text('KEPIN DUMPER', style: kDisplay(size: 22, w: FontWeight.w700, c: kText, ls: 3)),
                    const SizedBox(height: 14),
                    const SizedBox(width: 120, child: KBar(value: 0.4)),
                    const SizedBox(height: 10),
                    Text('MEMUAT SPLASH…', style: kMono(size: 10, c: kFaint, ls: 2)),
                  ],
                ),
              ),
            ),
          // scrim halus biar teks kebaca
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [kBgDeep.withOpacity(0.75), Colors.transparent, kBgDeep.withOpacity(0.35)],
                ),
              ),
            ),
          ),
          // skip
          Positioned(
            top: MediaQuery.of(context).padding.top + 14,
            right: 18,
            child: KTap(
              onTap: _go,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: kBgDeep.withOpacity(0.6),
                  borderRadius: BorderRadius.circular(99),
                  border: Border.all(color: kStroke),
                ),
                child: Text('LEWATI', style: kMono(size: 10, w: FontWeight.w700, c: kDim, ls: 1.6)),
              ),
            ),
          ),
          Positioned(
            bottom: 34,
            left: 0,
            right: 0,
            child: Column(
              children: [
                Text('KEPIN DUMPER', style: kDisplay(size: 15, w: FontWeight.w700, c: kText, ls: 4)),
                const SizedBox(height: 6),
                Text('ENGINE v3', style: kMono(size: 9, c: kFaint, ls: 2.4)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
